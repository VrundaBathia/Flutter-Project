package com.codeforany.trackizer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

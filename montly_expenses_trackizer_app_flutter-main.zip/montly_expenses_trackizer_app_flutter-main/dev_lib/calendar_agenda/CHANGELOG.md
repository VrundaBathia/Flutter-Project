## [0.0.2+3] - 2021-24-09

* add center parameter to SelectedDayPosition
* Update README.md
  
## [0.0.2+2] - 2021-22-09

* Add go to selected date in full calendar mode
* fixing bug in full calendar layout
* update the example of a package
  
## [0.0.2+1] - 2021-22-09

* fixing bug show/hide fullCalendar
* fixing day list width

## [0.0.2] - 2021-13-09

* Fixing alignment bug

## [0.0.1] - 2021-01-09

* Add color customization
* Add events date list
* Add two layout full calendar mode
* Add background image to selected day
* Add background image to full calendar view
* Add option selected day in left or right
* and another cool stuff

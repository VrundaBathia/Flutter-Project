/// This library is for swiper
library card_swiper;

export 'src/flutter_page_indicator/flutter_page_indicator.dart';
export 'src/swiper.dart';
export 'src/swiper_control.dart';
export 'src/swiper_controller.dart';
export 'src/swiper_pagination.dart';
export 'src/swiper_plugin.dart';
export 'src/transformer_page_view/index_controller.dart';

# Monthly Expenses Trackizer App UI UX Design Convent Into Flutter Code

# codeforany @codeforany

- [Youtube Full Playlist: Monthly Expenses  App UI UX Design Convent Into Flutter Code](https://www.youtube.com/playlist?list=PLzcRC7PA0xWQRSF-Crjk6q3AQArDgCxak)
- [Youtube Channel: @codeforany](https://www.youtube.com/channel/UCdQTp9wRK5vAOlEQZf9PHSg)
- [Youtube Channel Subscribe: @codeforany](https://www.youtube.com/channel/UCdQTp9wRK5vAOlEQZf9PHSg?sub_confirmation=1)

- [Youtube Video Part-1: App Induction, Sign Up Flow UI](https://youtu.be/A8Ou5iHU5lI)
- [Youtube Video Part-2: Bottom TabView UI, Home Tab UI](https://youtu.be/LwW4Z35n-wM)
- [Youtube Video Part-3: Spending Budgets Tab UI](https://youtu.be/LHkkCG8W5YI)
- [Youtube Video Part-4: Subscription Schedule Calendar Tab UI](https://youtu.be/aViCUzVWo7o)
- [Youtube Video Part-5: Add New Subscription UI](https://youtu.be/zNd3YDQu3sw)
- [Youtube Video Part-6: Subscription Info Details Screen UI](https://youtu.be/5-sb4jXf3bc)
- [Youtube Video Part-7: App Settings Screen UI](https://youtu.be/l9dM3X0Up0A)
- [Youtube Video Part-8: Add Credit Cards Tab UI](https://youtu.be/zlLowXpiAZw)

UI UX App Design by: [symu.co](https://symu.co/)

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
